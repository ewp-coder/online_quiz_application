from flask import Flask, render_template, redirect, request

app = Flask(__name__)

# Route for the front page (This is where the "Back" button from login redirects)
@app.route('/frontpage')
def frontpage():
    return render_template('frontpage.html')  # Serve the frontpage.html

# Route for the admin login page
@app.route('/login', methods=['GET', 'POST'])
def admin_login():
    if request.method == 'POST':
        username = request.form['username']
        password = request.form['password']
        
        # Validate admin credentials (you can replace this with a database check)
        valid_users = [{'username': 'Admin', 'password': 'Admin1234'}]  # Mocked admin users
        
        for user in valid_users:
            if user['username'] == username and user['password'] == password:
                return redirect('/dashboard')  # Redirect to dashboard on successful login
        
        # If login fails, show error
        return "Invalid credentials, please try again.", 401
    
    return render_template('login.html')  # Admin login page

# Route for the student login page
@app.route('/studentlogin', methods=['GET', 'POST'])
def student_login():
    if request.method == 'POST':
        email = request.form['email']
        password = request.form['password']
        
        # Validate student login (using mock data, for demo purposes)
        stored_user = {'email': 'student@example.com', 'password': 'student123'}
        
        if email == stored_user['email'] and password == stored_user['password']:
            return redirect('/goodluck')  # Redirect to "good luck" page on successful login
        else:
            return "Invalid email or password.", 401

    return render_template('studentlogin.html')  # Student login page

# Route for the student registration page
@app.route('/register', methods=['GET', 'POST'])
def student_register():
    if request.method == 'POST':
        # Handle registration logic
        name = request.form['name']
        email = request.form['email']
        password = request.form['password']
        
        # Mock store registration (you should save this to a database in a real app)
        return redirect('/studentlogin')  # After registration, redirect to student login
    
    return render_template('register.html')  # Registration page

# Route for the forgot password page
@app.route('/forgot', methods=['GET', 'POST'])
def forgot_password():
    if request.method == 'POST':
        email = request.form['email']
        # Handle password reset logic here (mocking for now)
        return redirect('/studentlogin')  # Redirect to student login after password reset
    
    return render_template('forgot.html')  # Forgot password page

# Route for the dashboard page (for admin)
@app.route('/dashboard')
def dashboard():
    return render_template('dashboard.html')  # Admin dashboard page

# Route for the student main page
@app.route('/student')
def student_page():
    return render_template('student.html')  # Student main page

# Route for viewing the student result page
@app.route('/result')
def result_page():
    return render_template('result.html')  # Results page

# Route for updating student information page
@app.route('/update', methods=['GET', 'POST'])
def update_student_info():
    if request.method == 'POST':
        # Handle the student info update logic here
        return redirect('/student')  # After update, redirect to student page
    
    return render_template('update.html')  # Student update page

# Route for the good luck page after student login
@app.route('/goodluck')
def good_luck():
    return render_template('goodluck.html')  # "Good Luck" page after login

# Route for the result page after student login
@app.route('/frontresult')
def front_result():
    return render_template('frontresult.html')  # Page showing student's result

# Route for the front page (This will be where the "Back" button from login redirects)
@app.route('/')
def home():
    return redirect('/frontpage')  # Redirect to the front page by default
# Route for index page
@app.route('/index')
def index():
    return render_template('index.html')

# Route for DCET-related page
@app.route('/dcet')
def dcet():
    return render_template('dcet.html')

# Route for Diploma-related page
@app.route('/diploma')
def diploma():
    return render_template('diploma.html')

# Route for alternate login page (logink.html)
@app.route('/logink')
def logink():
    return render_template('logink.html')



if __name__ == '__main__':
    app.run(debug=True)
