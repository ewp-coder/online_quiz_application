from flask import Flask, render_template, request, redirect, url_for, session, flash, send_from_directory
import os
import json
import pandas as pd
from werkzeug.security import generate_password_hash, check_password_hash
from werkzeug.utils import secure_filename
from datetime import datetime

app = Flask(__name__)
app.secret_key = 'your-secret-key'  # Replace with a secure key
app.config['UPLOAD_FOLDER'] = 'uploads'
app.config['ALLOWED_EXTENSIONS'] = {'xlsx', 'xls'}

# Ensure upload folder exists
if not os.path.exists(app.config['UPLOAD_FOLDER']):
    os.makedirs(app.config['UPLOAD_FOLDER'])

# Hardcoded users (username, hashed_password, role)
USERS = {
    'teacher1': {
        'password': generate_password_hash('teacherpass'),
        'role': 'teacher'
    },
    'principal1': {
        'password': generate_password_hash('principalpass'),
        'role': 'principal'
    }
}

# Path to store file metadata
METADATA_FILE = os.path.join(app.config['UPLOAD_FOLDER'], 'files.json')

def load_metadata():
    if os.path.exists(METADATA_FILE):
        with open(METADATA_FILE, 'r') as f:
            return json.load(f)
    return []

def save_metadata(metadata):
    with open(METADATA_FILE, 'w') as f:
        json.dump(metadata, f, indent=2)

def allowed_file(filename):
    return '.' in filename and filename.rsplit('.', 1)[1].lower() in app.config['ALLOWED_EXTENSIONS']

@app.route('/')
def index():
    return render_template('login.html')

@app.route('/login', methods=['POST'])
def login():
    username = request.form['username']
    password = request.form['password']
    
    if username in USERS and check_password_hash(USERS[username]['password'], password):
        session['username'] = username
        session['role'] = USERS[username]['role']
        if session['role'] == 'teacher':
            return redirect(url_for('teacher_dashboard'))
        elif session['role'] == 'principal':
            return redirect(url_for('principal_dashboard'))
    flash('Invalid credentials')
    return redirect(url_for('index'))

@app.route('/logout')
def logout():
    session.clear()
    return redirect(url_for('index'))

@app.route('/teacher')
def teacher_dashboard():
    if 'username' not in session or session['role'] != 'teacher':
        return redirect(url_for('index'))
    return render_template('teacher.html', username=session['username'])

@app.route('/upload', methods=['POST'])
def upload_file():
    if 'username' not in session or session['role'] != 'teacher':
        return redirect(url_for('index'))
    
    if 'file' not in request.files:
        flash('No file part')
        return redirect(url_for('teacher_dashboard'))
    
    file = request.files['file']
    semester = request.form['semester']
    year = request.form['year']
    
    if file.filename == '':
        flash('No file selected')
        return redirect(url_for('teacher_dashboard'))
    
    if file and allowed_file(file.filename) and semester and year:
        filename = secure_filename(file.filename)
        file_path = os.path.join(app.config['UPLOAD_FOLDER'], filename)
        file.save(file_path)
        
        # Load existing metadata
        metadata = load_metadata()
        
        # Append new file metadata
        metadata.append({
            'filename': filename,
            'semester': semester,
            'year': int(year),
            'upload_date': datetime.now().strftime('%Y-%m-%d %H:%M:%S'),
            'uploaded_by': session['username']
        })
        
        # Save updated metadata
        save_metadata(metadata)
        flash('File uploaded successfully')
    else:
        flash('Invalid file or missing semester/year')
    
    return redirect(url_for('teacher_dashboard'))

@app.route('/principal')
def principal_dashboard():
    if 'username' not in session or session['role'] != 'principal':
        return redirect(url_for('index'))
    
    semester = request.args.get('semester', '')
    year = request.args.get('year', '')
    
    # Load metadata
    files = load_metadata()
    
    # Filter files
    filtered_files = []
    for file in files:
        if semester and file['semester'] != semester:
            continue
        if year and file['year'] != int(year):
            continue
        filtered_files.append(file)
    
    return render_template('principal.html', files=filtered_files, username=session['username'], semester=semester, year=year)

@app.route('/uploads/<filename>')
def download_file(filename):
    if 'username' not in session or session['role'] != 'principal':
        return redirect(url_for('index'))
    return send_from_directory(app.config['UPLOAD_FOLDER'], filename)

if __name__ == '__main__':
    app.run(debug=True, host='0.0.0.0')